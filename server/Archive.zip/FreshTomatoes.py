import tornado.ioloop
import pyrestful.rest
import tornado.web
import tornado.options
import tornado.httpserver
import logging
import os
import sqlite3
import urllib2
import hashlib
from datetime import datetime
from pyrestful import mediatypes
from pyrestful.rest import get, post, put, delete

databaseName = 'FreshTomatoes.db'

class Movie(object):
    movie_name = str
    image_url = str
    rating = float
    description = str
	
class VersionHandler(tornado.web.RequestHandler):
    def get(self):
        response = { 'version': '1.0.0' }
        self.write(response)

class Database:
    con = sqlite3.Connection
    cur = sqlite3.Cursor
    
    def __init__(self):
        try:
            print databaseName
            self.con = sqlite3.connect(databaseName)
            print 'connected'
            print self.con
            self.cur_con()
        except sqlite3.Error, e:
            print "Error %s" % (e.args[0])
            return None

    def __del__(self):
        if self.con:
            self.con.close()

    def cur_con(self):
        self.cur = self.con.cursor()
        
class DatabaseHandler(Database):
    def is_request_valid(self, postbody):
        illegalCharacters = '`'
        for char in illegalCharacters:
          if char.lower() in postbody.lower():
            print "unquoted postbody failed validation check"
            return False
          if char.lower() in urllib2.unquote(postbody):
            print "postbody failed validation check"
            return False

        return True

    def query_one(self, sql, params, commit=False):
        self.cur_con()
        self.cur.execute(sql, params)
        if commit == False:
            data = self.cur.fetchone()
            self.cur.close()
            return data
        else:
            self.con.commit()
            id = self.con.insert_id()
            self.cur.close()
            return id

    def query_one_dict(self, sql, params, commit=False):
        self.cur_con()
        self.cur.execute(sql, params)
        if commit == False:
            data = self.cur.fetchone()
            if data is None: return None
            cols = [ d[0] for d in self.cur.description ]
            self.cur.close()
            return dict(zip(cols, data))
        else:
            self.con.commit()
            id = self.con.insert_id()
            self.cur.close()
            return id

    def query_one_dict_noparams(self, sql, commit=False):
        self.cur_con()
        self.cur.execute(sql)
        if commit == False:
            data = self.cur.fetchone()
            if data is None: return None
            cols = [ d[0] for d in self.cur.description ]
            self.cur.close()
            return dict(zip(cols, data))
        else:
            self.con.commit()
            id = self.con.insert_id()
            self.cur.close()
            return id

    def query_all_dict(self, sql):
        print 'lele'
        self.cur_con()
        print self.cur
        print sql
        self.cur.execute(sql)
        rows = self.cur.fetchall()
        print rows
        if rows is None: return None
        cols = [ d[0] for d in self.cur.description ]
        self.cur.close()
        data = []
        for row in rows:
          data.append(dict(zip(cols, row)))
        return data

    def query_execute(self, sql):
        self.cur_con()
        self.cur.execute(sql)
        return

class MovieResource(pyrestful.rest.RestHandler):
                
    @get(_path="/movies/json/{movie_name}", _types=[str], _produces=mediatypes.APPLICATION_JSON)
    def getMovieJSON(self, movie_name):
        db = DatabaseHandler()
        db.cur_con() 
        print db
        movieDict = db.query_all_dict("SELECT * FROM Movies")
        print movieDict
        #movieDict = db.query_one_dict_noparams(sql)
        print "ok2"
        print movieDict
        movie = None
        if movieDict is not None:
            movie = Movie()
            movie.movie_name = movieDict['movie_name']
            movie.image_url = movieDict['image_url']
            movie.rating = movieDict['rating']
            movie.description = movieDict['description']
            print movie
        print "ok3"
        return movie
    
	@get(_path="/movies/xml/{movie_name}", _types=[str], _produces=mediatypes.APPLICATION_XML)
	def getMovieXML(self, movie_name):
		movie = Movie()
		movie.movie_name = movie_name
		movie.description = "My movie for movie named "+movie_name

		return movie

	@post(_path="/movies/xml",_types=[Movie],_consumes=mediatypes.APPLICATION_XML, _produces=mediatypes.APPLICATION_XML)
	def postMovieXML(self, movie):
		""" this is an echo...returns the same xml document """
		return movie

	@post(_path="/movies/json",_types=[Movie],_consumes=mediatypes.APPLICATION_JSON, _produces=mediatypes.APPLICATION_JSON)
	def postMovieJSON(self, movie):
		""" this is an echo...returns the same json document """
		return movie

	@post(_path="/movies",_types=[Movie])
	def postMovie(self, movie):
		""" this is an echo, returns json or xml depending of request content-type """
		return movie

class RegisterNewUserHandler(tornado.web.RequestHandler):
    def get(self):
        db = DatabaseHandler()
        username = self.get_argument('username')
        password = self.get_argument('password')
        challenge = self.get_argument('challenge')

        if username == None or len(username) == 0 or password == None or len(password) == 0:
            self.write("|*|-6|*|");
            return

        username = username.lower()
        challengeTarget = ConvertMD5ToIphoneFormat(hashlib.md5(username + " lele " + password + " yaya kthxbye").hexdigest())

        if challenge.lower() != challengeTarget.lower():
            self.write("|*|-5|*|")
            return

        if ">" in username or "<" in username or "," in username or "|" in username or "*" in username:
            self.write("|*|-3|*|")
            return

        if len(username) > 14 or len(password) != 35:
            self.write("|*|-4|*|")
            return

        sql = "SELECT COUNT(username) FROM User where username = %s"
        params = (username,)
        user_exists = int(db.query_one(sql, params)[0])
        if user_exists != 0:
            self.write("|*|-1|*|")
            return

        sql = "INSERT INTO User (UserName, Password) VALUES (%s, %s)"
        params = (username, password)
        try:
            id = db.query_one(sql,params,True)
            #print "Returned id: " + str(id)
            sql = "SELECT id from User WHERE UserName = %s and Password = %s"
            id = db.query_one(sql,params)
            #print "Queried id: " + str(id)
            self.write("|*|"+ str(int(id[0])) + "|*|")
            return
        except:
            self.write("|*|-2|*|")

class AuthenticateUserHandler(tornado.web.RequestHandler):
    def get(self):
        db = DatabaseHandler()
        username = self.get_argument('username')
        password = self.get_argument('password')
        if username == None or len(username) == 0 or password == None or len(password) == 0:
            self.write("|*|-1|*|");
            return

        username = username.lower()

        if ">" in username or "<" in username or "," in username or "|" in username or "*" in username:
            self.write("|*|-1|*|")
            return

        if len(username) > 14 or len(password) != 35:
            self.write("|*|-1|*|")
            return

        sql = "SELECT * FROM User where username = %s AND password = %s"
        params = (username,password,)
        try:
            data = db.query_one_dict(sql, params)
        except:
            self.write("|*|-1|*|")
            return

        if data == None: #bad username/password
            self.write("|*|-1|*|")
            return

#        for key, value in data.items():
#            if str(value) == "None":
#                data[key] = "0"

        sbGameData = "|*|"
        sbGameData += str(data['id'])
        sbGameData += "|*|"
        sbGameData += data['UserName']
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreInfinism'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreInfinismLevel'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreInfinismDate'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreTerminism'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreTerminismLevel'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreTerminismDate'])
        sbGameData += "|*|"
        sbGameData += str(data['BestComboChains'])
        sbGameData += "|*|"
        sbGameData += str(data['BestComboTrisms'])
        sbGameData += "|*|"
#                    Int64 cp = 0;
#                    if (Int64.TryParse(userRows.Rows[0]["BestComboPoints"].ToString(), out cp) == false)
#                        Int64.TryParse(((Int64)userRows.Rows[0]["BestComboPoints"]).ToString(), out cp);
#                    sbGameData.Append(cp.ToString());
#                    sbGameData.Append("|*|");
        sbGameData += str(data['BestComboPoints'])
        sbGameData += "|*|"
        sbGameData += str(data['BestComboLevel'])
        sbGameData += "|*|"
        sbGameData += str(data['BestComboDate'])
        sbGameData += "|*|"
        sbGameData += str(data['Achievements'])
        sbGameData += "|*|"
        sbGameData += str(data['TotalScore'])
        sbGameData += "|*|"
        sbGameData += str(data['TotalTrisms'])
        sbGameData += "|*|"
        sbGameData += str(data['NumberOfGamesPlayed'])
        sbGameData += "|*|"

        if str(data['IsApproved']) == "1":
            sbGameData += "true"
        else:
            sbGameData += "false"
        sbGameData += "|*|"

        sbGameData += str(data['SyllogismRankings'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreExpertInfinism'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreExpertInfinismLevel'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreExpertInfinismDate'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreExpertTerminism'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreExpertTerminismLevel'])
        sbGameData += "|*|"
        sbGameData += str(data['BestScoreExpertTerminismDate'])
        sbGameData += "|*|"
        self.write(sbGameData)
        return

def rebuild_db():
    if os.path.isfile(databaseName):
        os.remove(databaseName)
    db = DatabaseHandler()
    db.cur_con() 
    db.query_execute("CREATE TABLE Movies (movie_name TEXT, image_url TEXT, rating FLOAT, description TEXT)")
    db.query_execute("""INSERT INTO Movies (movie_name, image_url, rating, description) VALUES ("k", "http://resizing.flixster.com/s8kIQtOhr36lGPkcUGCVeqVWw9Y=/180x270/dkpu1ddg7pbsk.cloudfront.net/movie/11/19/01/11190143_ori.jpg", 4.5, "When Tony Stark jumpstarts a dormant peacekeeping program things go awry and Earth's Mightiest Heroes, including Iron Man, Captain America Thor, The Incredible Hulk, Black Widow and Hawkeye, are put to the ultimate test as they battle to save the planet from destruction at the hands of the villainous Ultron.")""")
    db.query_execute("""INSERT INTO Movies (movie_name, image_url, rating, description) VALUES ("Furious 7", "http://resizing.flixster.com/tBSZ6CjTf-YkvC4o-VC0JFIY-vk=/170x270/dkpu1ddg7pbsk.cloudfront.net/movie/11/18/14/11181482_ori.jpg", 4.0, "Continuing the global exploits in the unstoppable franchise built on speed, Vin Diesel, Paul Walker and Dwayne Johnson lead the returning cast of Fast & Furious 7. James Wan directs this chapter of the hugely successful series that also welcomes back favorites Michelle Rodriguez, Jordana Brewster, Tyrese Gibson, Chris Ludacris Bridges, Elsa Pataky and Lucas Black. They are joined by international action stars new to the franchise including Jason Statham, Djimon Hounsou, Tony Jaa, Ronda Rousey and Kurt Russell.")""")
    db.query_execute("""INSERT INTO Movies (movie_name, image_url, rating, description) VALUES ("Tomorrowland", "http://resizing.flixster.com/dH2TEhqdJ5A6xxV3mQBPZ_1yEac=/180x267/dkpu1ddg7pbsk.cloudfront.net/movie/11/19/06/11190666_ori.jpg", 3.5, "From Disney comes two-time Oscar (R) winner Brad Bird's riveting, mystery adventure Tomorrowland, starring Academy Award (R) winner George Clooney. Bound by a shared destiny, former boy-genius Frank (Clooney), jaded by disillusionment, and Casey (Britt Robertson), a bright, optimistic teen bursting with scientific curiosity, embark on a danger-filled mission to unearth the secrets of an enigmatic place somewhere in time and space known only as Tomorrowland. What they must do there changes the world-and them-forever. Featuring a screenplay by Lost writer and co-creator Damon Lindelof and Brad Bird, from a story by Lindelof & Bird & Jeff Jensen, Tomorrowland promises to take audiences on a thrill ride of nonstop adventures through new dimensions that have only been dreamed of.(C) Walt Disney")""")
    db.query_execute("""INSERT INTO Movies (movie_name, image_url, rating, description) VALUES ("Pitch Perfect 2", "http://resizing.flixster.com/CSaptdyboc7JUz266OumNJHeAl4=/180x257/dkpu1ddg7pbsk.cloudfront.net/movie/11/19/12/11191224_ori.jpg", 3.0, "Surprise hit Pitch Perfect gets sequelized in this Universal Pictures production once again scripted by Kay Cannon. ~ Jeremy Wheeler, Rovi")""")
    db.query_execute("""INSERT INTO Movies (movie_name, image_url, rating, description) VALUES ("Mad Max: Fury Road", "http://resizing.flixster.com/GbDqFVUc_9VBNAnanZVQxlYD0ZM=/180x267/dkpu1ddg7pbsk.cloudfront.net/movie/11/19/12/11191276_ori.jpg", 4.0, "Filmmaker George Miller gears up for another post-apocalyptic action adventure with Fury Road, the fourth outing in the Mad Max film series. Charlize Theron stars alongside Tom Hardy (Bronson), with Zoe Kravitz, Adelaide Clemens, and Rosie Huntington Whiteley heading up the supporting cast. ~ Jeremy Wheeler, Rovi")""")
    db.query_execute("""INSERT INTO Movies (movie_name, image_url, rating, description) VALUES ("Far From The Madding Crowd", "http://resizing.flixster.com/c8g2_ZQY4dBR7lxc9zWgzQnA01U=/180x267/dkpu1ddg7pbsk.cloudfront.net/movie/11/19/09/11190928_ori.jpg", 4.5, "Based on the literary classic by Thomas Hardy, FAR FROM THE MADDING CROWD is the story of independent, beautiful and headstrong Bathsheba Everdene (Carey Mulligan), who attracts three very different suitors: Gabriel Oak (Matthias Schoenaerts), a sheep farmer, captivated by her fetching willfulness; Frank Troy (Tom Sturridge), a handsome and reckless Sergeant; and William Boldwood (Michael Sheen), a prosperous and mature bachelor. This timeless story of Bathsheba's choices and passions explores the nature of relationships and love - as well as the human ability to overcome hardships through resilience and perseverance. (C) Fox Searchlight")""")
    print db
    rows = db.query_all_dict("SELECT * FROM Movies")
    print rows
    return

def make_app():
    rebuild_db()
    return tornado.web.Application([
        (r"/version", VersionHandler),
        (r"/getmoviebyname/([0-9]+)", GetGameByIdHandler),
        (r"/movie", MovieHandler),
        (r"/AuthenticateUser", AuthenticateUserHandler)
    ])

if __name__ == "__main__":
    try:
        rebuild_db()
        print("Service started")
        app = pyrestful.rest.RestService([MovieResource])
        app.listen(8080)
        tornado.ioloop.IOLoop.instance().start()
    except KeyboardInterrupt:
        print("\nService stopped")

    #tornado.options.parse_command_line()
    #logging.getLogger().setLevel(logging.DEBUG)
    #logging.debug(("Logging to stdout"))
    #http_server = tornado.httpserver.HTTPServer(make_app(), xheaders = True)
    #http_server.listen(3334)
    #tornado.ioloop.IOLoop.instance().start()